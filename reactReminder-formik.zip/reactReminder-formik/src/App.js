import React from 'react'
import './App.css'
import { RegisterForm } from './RegisterForm'

function App () {
  return (
    <div className='app'>
      <RegisterForm/>
    </div>
  )
}

export default App
